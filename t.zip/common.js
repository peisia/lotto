function hr(){
    document.write("<hr>");
}
function br(){
    document.write("<br>");
}
function dw(s){
    document.write(s);
}